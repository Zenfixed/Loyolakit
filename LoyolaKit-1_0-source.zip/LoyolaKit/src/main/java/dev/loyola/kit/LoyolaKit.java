package dev.loyola.kit;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.UUID;

/**
 * LoyolaKit - PlayerKits-style kits (loaded from PlayerKits 2 kit files) plus /pkit edit,
 * a layout editor where players arrange the kit's items in their inventory and /pkit save it.
 */
public final class LoyolaKit extends JavaPlugin implements Listener, CommandExecutor, TabCompleter {

    // ---------------------------------------------------------------- styling

    private static final LegacyComponentSerializer SECTION = LegacyComponentSerializer.legacySection();
    private static final String SMALL_FROM = "abcdefghijklmnopqrstuvwxyz";
    private static final String SMALL_TO = "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘǫʀsᴛᴜᴠᴡxʏᴢ";

    private static Component gradient(String text, int from, int to) {
        Component out = Component.empty();
        int len = text.length();
        for (int i = 0; i < len; i++) {
            double t = len == 1 ? 0 : (double) i / (len - 1);
            int r = (int) Math.round(((from >> 16) & 255) + ((((to >> 16) & 255) - ((from >> 16) & 255)) * t));
            int g = (int) Math.round(((from >> 8) & 255) + ((((to >> 8) & 255) - ((from >> 8) & 255)) * t));
            int b = (int) Math.round((from & 255) + (((to & 255) - (from & 255)) * t));
            out = out.append(Component.text(String.valueOf(text.charAt(i)), TextColor.color(r, g, b)));
        }
        return out;
    }

    private static final Component PREFIX = gradient("ʟᴏʏᴏʟᴀᴋɪᴛ", 0x00C6FF, 0x0072FF)
            .append(Component.text(" » ", NamedTextColor.DARK_GRAY));

    /** Converts '&' legacy text (including &x&r&r&g&g&b&b hex) to a component. */
    private static Component legacy(String s) {
        return SECTION.deserialize(ChatColor.translateAlternateColorCodes('&', s));
    }

    private static Component noItalic(Component c) {
        return c.decoration(TextDecoration.ITALIC, false);
    }

    private static String smallCaps(String s) {
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            int idx = SMALL_FROM.indexOf(Character.toLowerCase(ch));
            sb.append(idx >= 0 ? SMALL_TO.charAt(idx) : ch);
        }
        return sb.toString();
    }

    private void msg(CommandSender to, String legacyText) {
        to.sendMessage(PREFIX.append(legacy(legacyText)));
    }

    // ---------------------------------------------------------------- model

    private static final class Kit {
        final String name;
        double cooldown;
        boolean oneTime;
        boolean permissionRequired;
        boolean clearInventory;
        final TreeMap<Integer, ItemStack> items = new TreeMap<>();
        ConfigurationSection display;
        final List<String> claimActions = new ArrayList<>();
        final List<String> errorActions = new ArrayList<>();

        Kit(String name) {
            this.name = name;
        }

        String perm() {
            return "loyolakit.kit." + name.toLowerCase(Locale.ROOT);
        }
    }

    /** Players currently in /pkit edit. */
    private static final class EditSession {
        final Kit kit;
        final ItemStack[] storage;
        final ItemStack[] armor;
        final ItemStack offhand;

        EditSession(Kit kit, ItemStack[] storage, ItemStack[] armor, ItemStack offhand) {
            this.kit = kit;
            this.storage = storage;
            this.armor = armor;
            this.offhand = offhand;
        }
    }

    private static final class KitMenu implements InventoryHolder {
        final boolean edit;
        final Map<Integer, Kit> slots = new HashMap<>();
        Inventory inv;

        KitMenu(boolean edit) {
            this.edit = edit;
        }

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private static final class PreviewMenu implements InventoryHolder {
        Inventory inv;

        @Override
        public Inventory getInventory() {
            return inv;
        }
    }

    private final Map<String, Kit> kits = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
    private final Map<UUID, EditSession> editing = new HashMap<>();
    private File kitsDir;
    private File dataDir;
    private File layoutDir;
    private File editDir;

    // ---------------------------------------------------------------- lifecycle

    @Override
    public void onEnable() {
        kitsDir = new File(getDataFolder(), "kits");
        dataDir = new File(getDataFolder(), "data");
        layoutDir = new File(getDataFolder(), "layouts");
        editDir = new File(getDataFolder(), "editing");
        for (File d : new File[]{kitsDir, dataDir, layoutDir, editDir}) {
            //noinspection ResultOfMethodCallIgnored
            d.mkdirs();
        }
        copyDefaultKits();
        loadKits();

        getServer().getPluginManager().registerEvents(this, this);
        for (String cmd : new String[]{"kit", "pkit"}) {
            if (getCommand(cmd) != null) {
                getCommand(cmd).setExecutor(this);
                getCommand(cmd).setTabCompleter(this);
            }
        }
        // anyone who was mid-edit when the server crashed gets their inventory back
        for (Player p : Bukkit.getOnlinePlayers()) restoreFromDisk(p);
    }

    @Override
    public void onDisable() {
        for (UUID id : new ArrayList<>(editing.keySet())) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) finishEdit(p, false, true);
        }
    }

    /** First run: copy the bundled kit files into plugins/LoyolaKit/kits. */
    private void copyDefaultKits() {
        String[] existing = kitsDir.list((d, n) -> n.toLowerCase(Locale.ROOT).endsWith(".yml"));
        if (existing != null && existing.length > 0) return;
        try (InputStream in = getResource("kits.index")) {
            if (in == null) return;
            BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (!line.isEmpty()) saveResource("kits/" + line, false);
            }
        } catch (IOException e) {
            getLogger().warning("Could not copy default kits: " + e.getMessage());
        }
    }

    private void loadKits() {
        kits.clear();
        File[] files = kitsDir.listFiles((d, n) -> n.toLowerCase(Locale.ROOT).endsWith(".yml"));
        if (files == null) return;
        for (File f : files) {
            String name = f.getName().substring(0, f.getName().length() - 4);
            try {
                YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
                Kit k = new Kit(name);
                k.cooldown = y.getDouble("cooldown", 0);
                k.oneTime = y.getBoolean("one_time", false);
                k.permissionRequired = y.getBoolean("permission_required", false);
                k.clearInventory = y.getBoolean("clear_inventory", false);
                k.display = y.getConfigurationSection("display");
                ConfigurationSection items = y.getConfigurationSection("items");
                if (items != null) {
                    for (String key : items.getKeys(false)) {
                        int n;
                        try {
                            n = Integer.parseInt(key);
                        } catch (NumberFormatException e) {
                            continue;
                        }
                        if (n < 1 || n > 41) continue;
                        ItemStack it = items.getItemStack(key + ".original");
                        if (it != null && !it.getType().isAir()) k.items.put(n, it);
                    }
                }
                readActions(y.getConfigurationSection("actions.claim"), k.claimActions);
                readActions(y.getConfigurationSection("actions.error"), k.errorActions);
                kits.put(name, k);
            } catch (Exception e) {
                getLogger().warning("Failed to load kit " + name + ": " + e.getMessage());
            }
        }
        getLogger().info("Loaded " + kits.size() + " kits.");
    }

    private static void readActions(ConfigurationSection sec, List<String> out) {
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            String a = sec.getString(key + ".action");
            if (a != null) out.add(a);
        }
    }

    // ---------------------------------------------------------------- player files

    private YamlConfiguration loadYaml(File f) {
        return f.exists() ? YamlConfiguration.loadConfiguration(f) : new YamlConfiguration();
    }

    private void saveYaml(YamlConfiguration y, File f) {
        try {
            y.save(f);
        } catch (IOException e) {
            getLogger().warning("Could not save " + f.getName() + ": " + e.getMessage());
        }
    }

    private File dataFile(UUID id) {
        return new File(dataDir, id + ".yml");
    }

    private File layoutFile(UUID id) {
        return new File(layoutDir, id + ".yml");
    }

    private File editFile(UUID id) {
        return new File(editDir, id + ".yml");
    }

    /** Saved layout for a player+kit: kit item number -> inventory slot (0-35). */
    private Map<Integer, Integer> loadLayout(UUID id, Kit k) {
        Map<Integer, Integer> map = new HashMap<>();
        YamlConfiguration y = loadYaml(layoutFile(id));
        ConfigurationSection sec = y.getConfigurationSection("kits." + k.name.toLowerCase(Locale.ROOT));
        if (sec == null) return map;
        for (String key : sec.getKeys(false)) {
            try {
                map.put(Integer.parseInt(key), sec.getInt(key));
            } catch (NumberFormatException ignored) {
            }
        }
        return map;
    }

    private void storeLayout(UUID id, Kit k, Map<Integer, Integer> map) {
        File f = layoutFile(id);
        YamlConfiguration y = loadYaml(f);
        String path = "kits." + k.name.toLowerCase(Locale.ROOT);
        y.set(path, null);
        boolean isDefault = true;
        for (Map.Entry<Integer, Integer> e : map.entrySet()) {
            if (e.getValue() != e.getKey() - 1) isDefault = false;
        }
        if (!isDefault) {
            for (Map.Entry<Integer, Integer> e : map.entrySet()) y.set(path + "." + e.getKey(), e.getValue());
        }
        saveYaml(y, f);
    }

    // ---------------------------------------------------------------- giving kits

    private static boolean isEmpty(ItemStack it) {
        return it == null || it.getType().isAir();
    }

    /**
     * Puts the kit's items into the player's inventory using the given layout.
     * Items whose slot is taken go to any free slot; leftovers are returned.
     */
    private List<ItemStack> placeKit(Player p, Kit k, Map<Integer, Integer> layout) {
        PlayerInventory inv = p.getInventory();
        Set<Integer> used = new HashSet<>();
        List<ItemStack> overflow = new ArrayList<>();
        for (Map.Entry<Integer, ItemStack> e : k.items.entrySet()) {
            int n = e.getKey();
            int slot = n - 1; // PlayerKits numbering lines up with Bukkit slots (36-39 armor, 40 offhand)
            if (n <= 36 && layout.containsKey(n)) {
                int s = layout.get(n);
                if (s >= 0 && s <= 35) slot = s;
            }
            if (!used.contains(slot) && isEmpty(inv.getItem(slot))) {
                inv.setItem(slot, e.getValue().clone());
                used.add(slot);
            } else {
                overflow.add(e.getValue().clone());
            }
        }
        List<ItemStack> left = new ArrayList<>();
        for (ItemStack it : overflow) left.addAll(inv.addItem(it).values());
        return left;
    }

    private void claim(Player p, Kit k) {
        if (editing.containsKey(p.getUniqueId())) {
            msg(p, "&cFinish editing first with &f/pkit save&c.");
            return;
        }
        if (k.permissionRequired && !p.hasPermission(k.perm())) {
            msg(p, "&cYou don't have permission to claim this kit.");
            runActions(p, k.errorActions);
            return;
        }
        File df = dataFile(p.getUniqueId());
        YamlConfiguration data = loadYaml(df);
        if (k.oneTime && data.getBoolean("claimed." + k.name.toLowerCase(Locale.ROOT), false)) {
            msg(p, "&cYou can only claim this kit once.");
            runActions(p, k.errorActions);
            return;
        }
        long remaining = data.getLong("cooldown." + k.name.toLowerCase(Locale.ROOT), 0) - System.currentTimeMillis();
        if (remaining > 0) {
            msg(p, "&cWait &f" + formatTime(remaining / 1000 + 1) + " &cto claim this kit again.");
            runActions(p, k.errorActions);
            return;
        }

        if (k.clearInventory) {
            p.getInventory().clear();
        }
        List<ItemStack> left = placeKit(p, k, loadLayout(p.getUniqueId(), k));
        for (ItemStack it : left) p.getWorld().dropItemNaturally(p.getLocation(), it);

        if (k.cooldown > 0) data.set("cooldown." + k.name.toLowerCase(Locale.ROOT),
                System.currentTimeMillis() + (long) (k.cooldown * 1000));
        if (k.oneTime) data.set("claimed." + k.name.toLowerCase(Locale.ROOT), true);
        saveYaml(data, df);

        p.updateInventory();
        msg(p, "&7You claimed the &f" + k.name + " &7kit.");
        runActions(p, k.claimActions);
    }

    private static String formatTime(long seconds) {
        long h = seconds / 3600, m = (seconds % 3600) / 60, s = seconds % 60;
        StringBuilder sb = new StringBuilder();
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (s > 0 || sb.length() == 0) sb.append(s).append("s");
        return sb.toString().trim();
    }

    /** Supports the "playsound: NAME;volume;pitch" action used by your kit files. */
    private void runActions(Player p, List<String> actions) {
        for (String a : actions) {
            int i = a.indexOf(':');
            if (i < 0) continue;
            String type = a.substring(0, i).trim().toLowerCase(Locale.ROOT);
            String arg = a.substring(i + 1).trim();
            if (type.equals("playsound")) {
                String[] parts = arg.split(";");
                Sound sound = findSound(parts[0].trim());
                if (sound == null) continue;
                float vol = 1f, pitch = 1f;
                try {
                    if (parts.length > 1) vol = Float.parseFloat(parts[1]);
                    if (parts.length > 2) pitch = Float.parseFloat(parts[2]);
                } catch (NumberFormatException ignored) {
                }
                p.playSound(p.getLocation(), sound, vol, pitch);
            } else if (type.equals("message")) {
                p.sendMessage(legacy(arg.replace("%player%", p.getName())));
            }
        }
    }

    private Map<String, Sound> soundNames;

    private Sound findSound(String enumStyleName) {
        if (soundNames == null) {
            soundNames = new HashMap<>();
            for (Sound s : Registry.SOUNDS) {
                soundNames.put(Registry.SOUNDS.getKey(s).getKey().replace('.', '_').toUpperCase(Locale.ROOT), s);
            }
        }
        return soundNames.get(enumStyleName.toUpperCase(Locale.ROOT));
    }

    // ---------------------------------------------------------------- menus

    private ItemStack displayItem(Player p, Kit k, boolean edit) {
        ConfigurationSection def = k.display == null ? null : k.display.getConfigurationSection("default");
        ConfigurationSection use = def;
        long remaining = 0;
        if (!edit) {
            YamlConfiguration data = loadYaml(dataFile(p.getUniqueId()));
            remaining = data.getLong("cooldown." + k.name.toLowerCase(Locale.ROOT), 0) - System.currentTimeMillis();
            if (k.permissionRequired && !p.hasPermission(k.perm()) && k.display != null
                    && k.display.isConfigurationSection("no_permission")) {
                use = k.display.getConfigurationSection("no_permission");
            } else if (remaining > 0 && k.display != null && k.display.isConfigurationSection("cooldown")) {
                use = k.display.getConfigurationSection("cooldown");
            }
        }
        Material mat = Material.CHEST;
        String name = "&f" + k.name;
        List<String> lore = new ArrayList<>();
        if (use != null) {
            Material m = Material.matchMaterial(use.getString("id", "CHEST"));
            if (m != null) mat = m;
            name = use.getString("name", name);
            lore.addAll(use.getStringList("lore"));
        }
        ItemStack it = new ItemStack(mat, Math.max(1, Math.min(64, use == null ? 1 : use.getInt("amount", 1))));
        ItemMeta meta = it.getItemMeta();
        String time = formatTime(Math.max(0, remaining / 1000 + 1));
        meta.displayName(noItalic(legacy(name.replace("%kit_name%", k.name))));
        List<Component> lines = new ArrayList<>();
        for (String l : lore) lines.add(noItalic(legacy(l.replace("%kit_name%", k.name).replace("%time%", time))));
        lines.add(noItalic(Component.empty()));
        if (edit) {
            lines.add(noItalic(legacy("&7Click to &barrange &7this kit's layout")));
        } else {
            lines.add(noItalic(legacy("&7Left-click: &bclaim")));
            lines.add(noItalic(legacy("&7Right-click: &bpreview")));
        }
        meta.lore(lines);
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP);
        it.setItemMeta(meta);
        return it;
    }

    private void openMenu(Player p, boolean edit) {
        if (kits.isEmpty()) {
            msg(p, "&cThere are no kits.");
            return;
        }
        KitMenu holder = new KitMenu(edit);
        int rows = Math.min(6, (kits.size() + 8) / 9);
        Component title = gradient(smallCaps(edit ? "edit kit layout" : "kits"), 0x00C6FF, 0x0072FF);
        holder.inv = Bukkit.createInventory(holder, rows * 9, title);
        int slot = 0;
        for (Kit k : kits.values()) {
            if (slot >= rows * 9) break;
            holder.slots.put(slot, k);
            holder.inv.setItem(slot, displayItem(p, k, edit));
            slot++;
        }
        p.openInventory(holder.inv);
    }

    private void openPreview(Player p, Kit k) {
        PreviewMenu holder = new PreviewMenu();
        holder.inv = Bukkit.createInventory(holder, 45, gradient(smallCaps(k.name + " preview"), 0x00C6FF, 0x0072FF));
        for (Map.Entry<Integer, ItemStack> e : k.items.entrySet()) {
            int idx = e.getKey() - 1; // bukkit inventory slot
            int chestSlot;
            if (idx < 9) chestSlot = 27 + idx;          // hotbar along the bottom of the storage block
            else if (idx < 36) chestSlot = idx - 9;      // main inventory
            else chestSlot = 36 + (idx - 36);            // boots, leggings, chestplate, helmet, offhand
            holder.inv.setItem(chestSlot, e.getValue().clone());
        }
        p.openInventory(holder.inv);
    }

    // ---------------------------------------------------------------- edit mode

    private boolean isEditing(Player p) {
        return editing.containsKey(p.getUniqueId());
    }

    private static ItemStack[] cloneAll(ItemStack[] in) {
        ItemStack[] out = new ItemStack[in.length];
        for (int i = 0; i < in.length; i++) out[i] = in[i] == null ? null : in[i].clone();
        return out;
    }

    private void startEdit(Player p, Kit k) {
        if (isEditing(p)) {
            msg(p, "&cYou are already editing. Use &f/pkit save&c.");
            return;
        }
        PlayerInventory inv = p.getInventory();
        // keep whatever they're holding on the cursor
        ItemStack cursor = p.getItemOnCursor();
        if (!isEmpty(cursor)) {
            p.setItemOnCursor(null);
            for (ItemStack left : inv.addItem(cursor).values()) p.getWorld().dropItemNaturally(p.getLocation(), left);
        }
        EditSession s = new EditSession(k, cloneAll(inv.getStorageContents()), cloneAll(inv.getArmorContents()),
                inv.getItemInOffHand().clone());

        // persist the real inventory so it can't be lost on a crash/restart
        YamlConfiguration y = new YamlConfiguration();
        y.set("storage", Arrays.asList(s.storage));
        y.set("armor", Arrays.asList(s.armor));
        y.set("offhand", s.offhand);
        saveYaml(y, editFile(p.getUniqueId()));

        editing.put(p.getUniqueId(), s);
        fillEditInventory(p, k, loadLayout(p.getUniqueId(), k));
        p.closeInventory();
        msg(p, "&7Editing the &f" + k.name + " &7kit. Press &fE &7and arrange your items.");
        msg(p, "&f/pkit save &7to keep it, &f/pkit reset &7for the default layout, &f/pkit cancel &7to leave.");
    }

    private void fillEditInventory(Player p, Kit k, Map<Integer, Integer> layout) {
        PlayerInventory inv = p.getInventory();
        inv.clear();
        placeKit(p, k, layout);
        p.updateInventory();
    }

    /** Works out which slot each kit item (1-36) sits in right now. */
    private Map<Integer, Integer> readLayoutFromInventory(Player p, Kit k) {
        Map<Integer, Integer> mapping = new TreeMap<>();
        Set<Integer> taken = new HashSet<>();
        ItemStack[] storage = p.getInventory().getStorageContents();
        for (int slot = 0; slot < 36 && slot < storage.length; slot++) {
            ItemStack it = storage[slot];
            if (isEmpty(it)) continue;
            int match = -1;
            int preferred = slot + 1;
            ItemStack pref = k.items.get(preferred);
            if (pref != null && !taken.contains(preferred) && pref.isSimilar(it) && pref.getAmount() == it.getAmount()) {
                match = preferred;
            } else {
                for (Map.Entry<Integer, ItemStack> e : k.items.entrySet()) {
                    int n = e.getKey();
                    if (n > 36 || taken.contains(n)) continue;
                    if (e.getValue().isSimilar(it) && e.getValue().getAmount() == it.getAmount()) {
                        match = n;
                        break;
                    }
                }
            }
            if (match > 0) {
                taken.add(match);
                mapping.put(match, slot);
            }
        }
        return mapping;
    }

    private void finishEdit(Player p, boolean save, boolean quiet) {
        EditSession s = editing.remove(p.getUniqueId());
        if (s == null) return;
        if (save) storeLayout(p.getUniqueId(), s.kit, readLayoutFromInventory(p, s.kit));
        restoreInventory(p, s.storage, s.armor, s.offhand);
        //noinspection ResultOfMethodCallIgnored
        editFile(p.getUniqueId()).delete();
        if (!quiet) {
            msg(p, save ? "&7Saved your &f" + s.kit.name + " &7layout." : "&7Edit cancelled, nothing was saved.");
        }
    }

    private void restoreInventory(Player p, ItemStack[] storage, ItemStack[] armor, ItemStack offhand) {
        p.setItemOnCursor(null);
        PlayerInventory inv = p.getInventory();
        inv.clear();
        inv.setStorageContents(storage);
        inv.setArmorContents(armor);
        inv.setItemInOffHand(offhand);
        p.updateInventory();
    }

    private void restoreFromDisk(Player p) {
        if (isEditing(p)) return;
        File f = editFile(p.getUniqueId());
        if (!f.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        ItemStack[] storage = listToArray(y.getList("storage"), 36);
        ItemStack[] armor = listToArray(y.getList("armor"), 4);
        ItemStack offhand = y.getItemStack("offhand");
        restoreInventory(p, storage, armor, offhand == null ? new ItemStack(Material.AIR) : offhand);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
        msg(p, "&7Your inventory was restored from an unfinished kit edit.");
    }

    private static ItemStack[] listToArray(List<?> list, int size) {
        ItemStack[] out = new ItemStack[size];
        if (list == null) return out;
        for (int i = 0; i < size && i < list.size(); i++) {
            Object o = list.get(i);
            if (o instanceof ItemStack) out[i] = (ItemStack) o;
        }
        return out;
    }

    // ---------------------------------------------------------------- commands

    private Kit findKit(String name) {
        return kits.get(name);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("kit")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage("Players only.");
                return true;
            }
            Player p = (Player) sender;
            if (isEditing(p)) {
                msg(p, "&cFinish editing first with &f/pkit save&c.");
                return true;
            }
            if (args.length == 0) {
                openMenu(p, false);
                return true;
            }
            Kit k = findKit(args[0]);
            if (k == null) {
                msg(p, "&cThat kit doesn't exist.");
                return true;
            }
            claim(p, k);
            return true;
        }

        // /pkit
        if (args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("loyolakit.admin")) {
                msg(sender, "&cYou can't do that.");
                return true;
            }
            loadKits();
            msg(sender, "&7Reloaded &f" + kits.size() + " &7kits.");
            return true;
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage("Players only.");
            return true;
        }
        Player p = (Player) sender;
        String sub = args.length == 0 ? "help" : args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "edit": {
                if (isEditing(p)) {
                    msg(p, "&cYou are already editing. Use &f/pkit save&c.");
                    return true;
                }
                if (args.length < 2) {
                    openMenu(p, true);
                    return true;
                }
                Kit k = findKit(args[1]);
                if (k == null) {
                    msg(p, "&cThat kit doesn't exist.");
                    return true;
                }
                startEdit(p, k);
                return true;
            }
            case "save": {
                if (!isEditing(p)) {
                    msg(p, "&cYou aren't editing a kit.");
                    return true;
                }
                finishEdit(p, true, false);
                return true;
            }
            case "cancel": {
                if (!isEditing(p)) {
                    msg(p, "&cYou aren't editing a kit.");
                    return true;
                }
                finishEdit(p, false, false);
                return true;
            }
            case "reset": {
                EditSession s = editing.get(p.getUniqueId());
                if (s != null) {
                    fillEditInventory(p, s.kit, new HashMap<>());
                    msg(p, "&7Layout reset to default. &f/pkit save &7to keep it.");
                    return true;
                }
                if (args.length < 2) {
                    msg(p, "&cUse &f/pkit reset <kit>&c.");
                    return true;
                }
                Kit k = findKit(args[1]);
                if (k == null) {
                    msg(p, "&cThat kit doesn't exist.");
                    return true;
                }
                storeLayout(p.getUniqueId(), k, new HashMap<>());
                msg(p, "&7Your &f" + k.name + " &7layout was reset to default.");
                return true;
            }
            default: {
                msg(p, "&f/pkit edit [kit] &7- arrange a kit's layout");
                msg(p, "&f/pkit save &7- keep your layout  &f/pkit reset &7- default layout  &f/pkit cancel &7- leave");
                return true;
            }
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (cmd.getName().equalsIgnoreCase("kit")) {
            if (args.length == 1) addMatching(out, kits.keySet(), args[0]);
            return out;
        }
        if (args.length == 1) {
            addMatching(out, Arrays.asList("edit", "save", "cancel", "reset", "reload"), args[0]);
        } else if (args.length == 2 && (args[0].equalsIgnoreCase("edit") || args[0].equalsIgnoreCase("reset"))) {
            addMatching(out, kits.keySet(), args[1]);
        }
        return out;
    }

    private static void addMatching(List<String> out, Iterable<String> options, String typed) {
        for (String o : options) {
            if (o.toLowerCase(Locale.ROOT).startsWith(typed.toLowerCase(Locale.ROOT))) out.add(o);
        }
    }

    // ---------------------------------------------------------------- listeners: menus

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        Player p = (Player) e.getWhoClicked();
        InventoryHolder top = e.getView().getTopInventory().getHolder();

        if (top instanceof PreviewMenu) {
            e.setCancelled(true);
            return;
        }
        if (top instanceof KitMenu) {
            e.setCancelled(true);
            KitMenu menu = (KitMenu) top;
            if (e.getClickedInventory() == null || e.getClickedInventory() != e.getView().getTopInventory()) return;
            Kit k = menu.slots.get(e.getSlot());
            if (k == null) return;
            if (menu.edit) {
                Bukkit.getScheduler().runTask(this, () -> {
                    p.closeInventory();
                    startEdit(p, k);
                });
            } else if (e.getClick() == ClickType.RIGHT || e.getClick() == ClickType.SHIFT_RIGHT) {
                Bukkit.getScheduler().runTask(this, () -> openPreview(p, k));
            } else {
                Bukkit.getScheduler().runTask(this, () -> {
                    claim(p, k);
                    if (p.getOpenInventory().getTopInventory().getHolder() instanceof KitMenu) {
                        openMenu(p, false); // refresh cooldown icons
                    }
                });
            }
            return;
        }

        if (!isEditing(p)) return;

        // ---- edit mode: the only thing allowed is moving items around inventory slots 0-35
        if (!(e.getClickedInventory() instanceof PlayerInventory)) {
            e.setCancelled(true);
            return;
        }
        InventoryAction a = e.getAction();
        boolean allowedAction = a == InventoryAction.PICKUP_ALL
                || a == InventoryAction.PLACE_ALL
                || a == InventoryAction.SWAP_WITH_CURSOR
                || a == InventoryAction.HOTBAR_SWAP;
        if (!allowedAction || e.getSlot() < 0 || e.getSlot() > 35) {
            e.setCancelled(true);
            return;
        }
        // stacks must never merge or split
        if (!isEmpty(e.getCursor()) && !isEmpty(e.getCurrentItem()) && e.getCursor().isSimilar(e.getCurrentItem())) {
            e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent e) {
        if (!(e.getWhoClicked() instanceof Player)) return;
        InventoryHolder top = e.getView().getTopInventory().getHolder();
        if (top instanceof KitMenu || top instanceof PreviewMenu || isEditing((Player) e.getWhoClicked())) {
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onOpen(InventoryOpenEvent e) {
        if (!(e.getPlayer() instanceof Player)) return;
        if (isEditing((Player) e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        if (!(e.getPlayer() instanceof Player)) return;
        Player p = (Player) e.getPlayer();
        if (!isEditing(p)) return;
        // closing with something on the cursor would drop it - put it back in a free slot instead
        ItemStack cursor = p.getItemOnCursor();
        if (!isEmpty(cursor)) {
            p.setItemOnCursor(null);
            p.getInventory().addItem(cursor);
        }
    }

    // ---------------------------------------------------------------- listeners: edit lock

    @EventHandler(priority = EventPriority.LOWEST)
    public void onCommandPreprocess(PlayerCommandPreprocessEvent e) {
        if (!isEditing(e.getPlayer())) return;
        String first = e.getMessage().substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        if (first.startsWith("loyolakit:")) first = first.substring("loyolakit:".length());
        if (!first.equals("pkit")) {
            e.setCancelled(true);
            msg(e.getPlayer(), "&cYou can only use &f/pkit &cwhile editing.");
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent e) {
        if (!isEditing(e.getPlayer())) return;
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (from.getX() != to.getX() || from.getY() != to.getY() || from.getZ() != to.getZ()) {
            e.setTo(new Location(from.getWorld(), from.getX(), from.getY(), from.getZ(), to.getYaw(), to.getPitch()));
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent e) {
        if (isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onInteractEntity(PlayerInteractEntityEvent e) {
        if (isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onDrop(PlayerDropItemEvent e) {
        if (isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onSwapHands(PlayerSwapHandItemsEvent e) {
        if (isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent e) {
        if (isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onBreak(BlockBreakEvent e) {
        if (isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPlace(BlockPlaceEvent e) {
        if (isEditing(e.getPlayer())) e.setCancelled(true);
    }

    @EventHandler
    public void onPickup(EntityPickupItemEvent e) {
        if (e.getEntity() instanceof Player && isEditing((Player) e.getEntity())) e.setCancelled(true);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent e) {
        if (e.getEntity() instanceof Player && isEditing((Player) e.getEntity())) e.setCancelled(true);
    }

    @EventHandler
    public void onDamageBy(EntityDamageByEntityEvent e) {
        if (e.getDamager() instanceof Player && isEditing((Player) e.getDamager())) e.setCancelled(true);
    }

    // ---------------------------------------------------------------- listeners: join / quit

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        if (isEditing(e.getPlayer())) finishEdit(e.getPlayer(), false, true);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (p.isOnline()) restoreFromDisk(p);
        }, 5L);
    }
}
